def escape(str){
    return str.replaceAll("-", "_");
}
def props = [:]
def parent = "aem-clientlib-async"
props.path = ask("What path will clientlib-async be under? [${projectDir}]", "/apps/clientlib-async", "path")
props.path = "${props.path}/${parent}"
props.packageName = "${props.path}.${escape(parent)}"

processTemplates "clientlib.html", props
processTemplates "ClientLibUseObject.java", props
processTemplates "graniteClientLib.html", props